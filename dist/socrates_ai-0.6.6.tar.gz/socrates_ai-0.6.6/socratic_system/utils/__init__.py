"""Utility functions for Socratic RAG System"""
