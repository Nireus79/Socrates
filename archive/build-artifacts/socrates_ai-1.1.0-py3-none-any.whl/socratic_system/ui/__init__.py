"""User interface for Socratic RAG System"""

from .main_app import SocraticRAGSystem

__all__ = ["SocraticRAGSystem"]
